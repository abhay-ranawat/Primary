--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.18
-- Dumped by pg_dump version 10.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.members DROP CONSTRAINT members_fk2;
ALTER TABLE ONLY public.members DROP CONSTRAINT members_fk1;
ALTER TABLE ONLY public.members DROP CONSTRAINT members_fk0;
ALTER TABLE ONLY public.book_issue DROP CONSTRAINT book_issue_fk1;
ALTER TABLE ONLY public.book_issue DROP CONSTRAINT book_issue_fk0;
ALTER TABLE ONLY public.book_copies DROP CONSTRAINT book_copies_fk0;
ALTER TABLE ONLY public.book_authors DROP CONSTRAINT book_authors_fk0;
ALTER TABLE ONLY public.students DROP CONSTRAINT students_pk;
ALTER TABLE ONLY public.staff DROP CONSTRAINT staff_pk;
ALTER TABLE ONLY public.quota DROP CONSTRAINT quota_pk;
ALTER TABLE ONLY public.members DROP CONSTRAINT members_pk;
ALTER TABLE ONLY public.faculty DROP CONSTRAINT faculty_pk;
ALTER TABLE ONLY public.book_issue DROP CONSTRAINT book_issue_pk;
ALTER TABLE ONLY public.book_issue DROP CONSTRAINT book_issue_accession_no_key;
ALTER TABLE ONLY public.book_copies DROP CONSTRAINT book_copies_pk;
ALTER TABLE ONLY public.book_copies DROP CONSTRAINT book_copies_accession_no_key;
ALTER TABLE ONLY public.book_catalogue DROP CONSTRAINT book_catalogue_pk;
ALTER TABLE ONLY public.book_authors DROP CONSTRAINT book_authors_pk;
DROP TABLE public.students;
DROP TABLE public.staff;
DROP TABLE public.quota;
DROP TABLE public.members;
DROP TABLE public.faculty;
DROP TABLE public.book_issue;
DROP TABLE public.book_copies;
DROP TABLE public.book_catalogue;
DROP TABLE public.book_authors;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: book_authors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book_authors (
    isbn_no character varying(13) NOT NULL,
    author_fname character varying(80) NOT NULL,
    author_lname character varying(80) NOT NULL
);


ALTER TABLE public.book_authors OWNER TO postgres;

--
-- Name: book_catalogue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book_catalogue (
    isbn_no character varying(50) NOT NULL,
    title character varying(256) NOT NULL,
    publisher character varying(80) NOT NULL,
    year integer NOT NULL
);


ALTER TABLE public.book_catalogue OWNER TO postgres;

--
-- Name: book_copies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book_copies (
    isbn_no character varying(13) NOT NULL,
    accession_no character varying(20) NOT NULL
);


ALTER TABLE public.book_copies OWNER TO postgres;

--
-- Name: book_issue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book_issue (
    member_no character varying(20) NOT NULL,
    accession_no character varying(20) NOT NULL,
    doi date NOT NULL
);


ALTER TABLE public.book_issue OWNER TO postgres;

--
-- Name: faculty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faculty (
    faculty_fname character varying(80) NOT NULL,
    faculty_lname character varying(80) NOT NULL,
    id character varying(20) NOT NULL,
    department character varying(80) NOT NULL,
    gender character varying(1) NOT NULL,
    mobile_no numeric(10,0) NOT NULL,
    doj date NOT NULL
);


ALTER TABLE public.faculty OWNER TO postgres;

--
-- Name: members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.members (
    member_no character varying(20) NOT NULL,
    member_class character varying(20) NOT NULL,
    member_type character varying(2) NOT NULL,
    roll_no character varying(20),
    id character varying(20)
);


ALTER TABLE public.members OWNER TO postgres;

--
-- Name: quota; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quota (
    member_type character varying(2) NOT NULL,
    max_books integer NOT NULL,
    max_duration integer NOT NULL
);


ALTER TABLE public.quota OWNER TO postgres;

--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    staff_fname character varying(80) NOT NULL,
    staff_lname character varying(80) NOT NULL,
    id character varying(20) NOT NULL,
    gender character varying(1) NOT NULL,
    mobile_no numeric(10,0) NOT NULL,
    doj date NOT NULL
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    student_fname character varying(80) NOT NULL,
    student_lname character varying(80) NOT NULL,
    roll_no character varying(20) NOT NULL,
    department character varying(80) NOT NULL,
    gender character varying(1) NOT NULL,
    mobile_no numeric(10,0) NOT NULL,
    dob date NOT NULL,
    degree character varying(80) NOT NULL
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Data for Name: book_authors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book_authors (isbn_no, author_fname, author_lname) FROM stdin;
\.
COPY public.book_authors (isbn_no, author_fname, author_lname) FROM '$$PATH$$/2850.dat';

--
-- Data for Name: book_catalogue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book_catalogue (isbn_no, title, publisher, year) FROM stdin;
\.
COPY public.book_catalogue (isbn_no, title, publisher, year) FROM '$$PATH$$/2851.dat';

--
-- Data for Name: book_copies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book_copies (isbn_no, accession_no) FROM stdin;
\.
COPY public.book_copies (isbn_no, accession_no) FROM '$$PATH$$/2852.dat';

--
-- Data for Name: book_issue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book_issue (member_no, accession_no, doi) FROM stdin;
\.
COPY public.book_issue (member_no, accession_no, doi) FROM '$$PATH$$/2853.dat';

--
-- Data for Name: faculty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faculty (faculty_fname, faculty_lname, id, department, gender, mobile_no, doj) FROM stdin;
\.
COPY public.faculty (faculty_fname, faculty_lname, id, department, gender, mobile_no, doj) FROM '$$PATH$$/2854.dat';

--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.members (member_no, member_class, member_type, roll_no, id) FROM stdin;
\.
COPY public.members (member_no, member_class, member_type, roll_no, id) FROM '$$PATH$$/2855.dat';

--
-- Data for Name: quota; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quota (member_type, max_books, max_duration) FROM stdin;
\.
COPY public.quota (member_type, max_books, max_duration) FROM '$$PATH$$/2856.dat';

--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff (staff_fname, staff_lname, id, gender, mobile_no, doj) FROM stdin;
\.
COPY public.staff (staff_fname, staff_lname, id, gender, mobile_no, doj) FROM '$$PATH$$/2857.dat';

--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (student_fname, student_lname, roll_no, department, gender, mobile_no, dob, degree) FROM stdin;
\.
COPY public.students (student_fname, student_lname, roll_no, department, gender, mobile_no, dob, degree) FROM '$$PATH$$/2858.dat';

--
-- Name: book_authors book_authors_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_authors
    ADD CONSTRAINT book_authors_pk PRIMARY KEY (isbn_no, author_fname, author_lname);


--
-- Name: book_catalogue book_catalogue_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_catalogue
    ADD CONSTRAINT book_catalogue_pk PRIMARY KEY (isbn_no);


--
-- Name: book_copies book_copies_accession_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_copies
    ADD CONSTRAINT book_copies_accession_no_key UNIQUE (accession_no);


--
-- Name: book_copies book_copies_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_copies
    ADD CONSTRAINT book_copies_pk PRIMARY KEY (isbn_no, accession_no);


--
-- Name: book_issue book_issue_accession_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_issue
    ADD CONSTRAINT book_issue_accession_no_key UNIQUE (accession_no);


--
-- Name: book_issue book_issue_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_issue
    ADD CONSTRAINT book_issue_pk PRIMARY KEY (member_no, accession_no);


--
-- Name: faculty faculty_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faculty
    ADD CONSTRAINT faculty_pk PRIMARY KEY (id);


--
-- Name: members members_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pk PRIMARY KEY (member_no);


--
-- Name: quota quota_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quota
    ADD CONSTRAINT quota_pk PRIMARY KEY (member_type);


--
-- Name: staff staff_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pk PRIMARY KEY (id);


--
-- Name: students students_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pk PRIMARY KEY (roll_no);


--
-- Name: book_authors book_authors_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_authors
    ADD CONSTRAINT book_authors_fk0 FOREIGN KEY (isbn_no) REFERENCES public.book_catalogue(isbn_no);


--
-- Name: book_copies book_copies_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_copies
    ADD CONSTRAINT book_copies_fk0 FOREIGN KEY (isbn_no) REFERENCES public.book_catalogue(isbn_no);


--
-- Name: book_issue book_issue_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_issue
    ADD CONSTRAINT book_issue_fk0 FOREIGN KEY (member_no) REFERENCES public.members(member_no);


--
-- Name: book_issue book_issue_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_issue
    ADD CONSTRAINT book_issue_fk1 FOREIGN KEY (accession_no) REFERENCES public.book_copies(accession_no);


--
-- Name: members members_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_fk0 FOREIGN KEY (member_type) REFERENCES public.quota(member_type);


--
-- Name: members members_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_fk1 FOREIGN KEY (roll_no) REFERENCES public.students(roll_no);


--
-- Name: members members_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_fk2 FOREIGN KEY (id) REFERENCES public.faculty(id);


--
-- PostgreSQL database dump complete
--

