--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.18
-- Dumped by pg_dump version 10.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.players DROP CONSTRAINT players_fk0;
ALTER TABLE ONLY public.matches DROP CONSTRAINT matches_fk1;
ALTER TABLE ONLY public.matches DROP CONSTRAINT matches_fk0;
ALTER TABLE ONLY public.match_referees DROP CONSTRAINT match_referees_fk5;
ALTER TABLE ONLY public.match_referees DROP CONSTRAINT match_referees_fk4;
ALTER TABLE ONLY public.match_referees DROP CONSTRAINT match_referees_fk3;
ALTER TABLE ONLY public.match_referees DROP CONSTRAINT match_referees_fk2;
ALTER TABLE ONLY public.match_referees DROP CONSTRAINT match_referees_fk0;
ALTER TABLE ONLY public.managers DROP CONSTRAINT managers_fk3;
ALTER TABLE ONLY public.teams DROP CONSTRAINT teams_pk;
ALTER TABLE ONLY public.referees DROP CONSTRAINT referees_pk;
ALTER TABLE ONLY public.players DROP CONSTRAINT players_pk;
ALTER TABLE ONLY public.matches DROP CONSTRAINT matches_pk;
ALTER TABLE ONLY public.match_referees DROP CONSTRAINT match_referees_pkey;
ALTER TABLE ONLY public.managers DROP CONSTRAINT managers_pk;
DROP TABLE public.teams;
DROP TABLE public.referees;
DROP TABLE public.players;
DROP TABLE public.matches;
DROP TABLE public.match_referees;
DROP TABLE public.managers;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: managers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.managers (
    mgr_id character varying(10) NOT NULL,
    name character varying(80) NOT NULL,
    dob date NOT NULL,
    team_id character varying(10),
    since date
);


ALTER TABLE public.managers OWNER TO postgres;

--
-- Name: match_referees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.match_referees (
    match_num character varying(10) NOT NULL,
    referee character varying(15),
    assistant_referee_1 character varying(15),
    assistant_referee_2 character varying(15),
    fourth_referee character varying(15)
);


ALTER TABLE public.match_referees OWNER TO postgres;

--
-- Name: matches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.matches (
    match_num character varying(10) NOT NULL,
    match_date date NOT NULL,
    host_team_id character varying(10) NOT NULL,
    guest_team_id character varying(10) NOT NULL,
    host_team_score integer NOT NULL,
    guest_team_score integer NOT NULL
);


ALTER TABLE public.matches OWNER TO postgres;

--
-- Name: players; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.players (
    player_id character varying(10) NOT NULL,
    name character varying(80) NOT NULL,
    dob date NOT NULL,
    jersey_no integer NOT NULL,
    team_id character varying(10) NOT NULL
);


ALTER TABLE public.players OWNER TO postgres;

--
-- Name: referees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.referees (
    referee_id character varying(10) NOT NULL,
    name character varying(80) NOT NULL,
    dob date NOT NULL
);


ALTER TABLE public.referees OWNER TO postgres;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teams (
    team_id character varying(10) NOT NULL,
    name character varying(80) NOT NULL,
    city character varying(80) NOT NULL,
    playground character varying(80) NOT NULL,
    jersey_home_color character varying(80),
    jersey_away_color character varying(80)
);


ALTER TABLE public.teams OWNER TO postgres;

--
-- Data for Name: managers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.managers (mgr_id, name, dob, team_id, since) FROM stdin;
\.
COPY public.managers (mgr_id, name, dob, team_id, since) FROM '$$PATH$$/2830.dat';

--
-- Data for Name: match_referees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.match_referees (match_num, referee, assistant_referee_1, assistant_referee_2, fourth_referee) FROM stdin;
\.
COPY public.match_referees (match_num, referee, assistant_referee_1, assistant_referee_2, fourth_referee) FROM '$$PATH$$/2831.dat';

--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.matches (match_num, match_date, host_team_id, guest_team_id, host_team_score, guest_team_score) FROM stdin;
\.
COPY public.matches (match_num, match_date, host_team_id, guest_team_id, host_team_score, guest_team_score) FROM '$$PATH$$/2832.dat';

--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.players (player_id, name, dob, jersey_no, team_id) FROM stdin;
\.
COPY public.players (player_id, name, dob, jersey_no, team_id) FROM '$$PATH$$/2833.dat';

--
-- Data for Name: referees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.referees (referee_id, name, dob) FROM stdin;
\.
COPY public.referees (referee_id, name, dob) FROM '$$PATH$$/2834.dat';

--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teams (team_id, name, city, playground, jersey_home_color, jersey_away_color) FROM stdin;
\.
COPY public.teams (team_id, name, city, playground, jersey_home_color, jersey_away_color) FROM '$$PATH$$/2835.dat';

--
-- Name: managers managers_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.managers
    ADD CONSTRAINT managers_pk PRIMARY KEY (mgr_id);


--
-- Name: match_referees match_referees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match_referees
    ADD CONSTRAINT match_referees_pkey PRIMARY KEY (match_num);


--
-- Name: matches matches_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pk PRIMARY KEY (match_num);


--
-- Name: players players_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pk PRIMARY KEY (player_id);


--
-- Name: referees referees_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.referees
    ADD CONSTRAINT referees_pk PRIMARY KEY (referee_id);


--
-- Name: teams teams_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pk PRIMARY KEY (team_id);


--
-- Name: managers managers_fk3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.managers
    ADD CONSTRAINT managers_fk3 FOREIGN KEY (team_id) REFERENCES public.teams(team_id);


--
-- Name: match_referees match_referees_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match_referees
    ADD CONSTRAINT match_referees_fk0 FOREIGN KEY (match_num) REFERENCES public.matches(match_num);


--
-- Name: match_referees match_referees_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match_referees
    ADD CONSTRAINT match_referees_fk2 FOREIGN KEY (referee) REFERENCES public.referees(referee_id);


--
-- Name: match_referees match_referees_fk3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match_referees
    ADD CONSTRAINT match_referees_fk3 FOREIGN KEY (assistant_referee_1) REFERENCES public.referees(referee_id);


--
-- Name: match_referees match_referees_fk4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match_referees
    ADD CONSTRAINT match_referees_fk4 FOREIGN KEY (assistant_referee_2) REFERENCES public.referees(referee_id);


--
-- Name: match_referees match_referees_fk5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match_referees
    ADD CONSTRAINT match_referees_fk5 FOREIGN KEY (fourth_referee) REFERENCES public.referees(referee_id);


--
-- Name: matches matches_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_fk0 FOREIGN KEY (host_team_id) REFERENCES public.teams(team_id);


--
-- Name: matches matches_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_fk1 FOREIGN KEY (guest_team_id) REFERENCES public.teams(team_id);


--
-- Name: players players_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_fk0 FOREIGN KEY (team_id) REFERENCES public.teams(team_id);


--
-- PostgreSQL database dump complete
--

